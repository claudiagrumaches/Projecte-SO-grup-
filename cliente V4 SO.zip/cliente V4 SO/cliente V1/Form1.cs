﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace cliente_V1
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void AtenderServidor()
        {
            while (true)
            {
                //Recibimos mensaje del servidor
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                string[] trozos = Encoding.ASCII.GetString(msg2).Split('/');
                int codigo = Convert.ToInt32(trozos[0]);
                string mensaje = mensaje = trozos[1].Split('\0')[0];

                switch (codigo)
                {
                    case 2:
                        MessageBox.Show(mensaje);
                        break;
                    case 3:
                        MessageBox.Show(mensaje);
                        break;
                    case 4:
                        MessageBox.Show(mensaje);
                        break;
                    case 5:
                        MessageBox.Show(mensaje);
                        break;
                    case 6:
                        MessageBox.Show(mensaje);
                        break;
                    case 7:
                        //contLbl.Text = mensaje;
                        string[] conectados = mensaje.Split('/');
                        Conectados.Invoke((MethodInvoker)delegate
                        {
                            Conectados.Rows.Clear(); // Borrar todo antes de actualizar
                            for (int i = 0; i < conectados.Length; i++)
                            {
                                if (!string.IsNullOrWhiteSpace(conectados[i]))
                                    Conectados.Rows.Add(conectados[i]);
                            }
                        });
                        break;

                }
            }
        }
                     
        // Botón Conectar
        private void Conectar_Click(object sender, EventArgs e)
        {
            try
            {
                // Se utiliza la IP del servidor y el puerto 9000, que es el definido en el servidor
                IPAddress direc = IPAddress.Parse("192.168.56.102"); //REVISAR QUE LA IP SEA LA CORRECTA
                IPEndPoint ipep = new IPEndPoint(direc, 50035);

                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                server.Connect(ipep);
                this.BackColor = Color.Green;
                MessageBox.Show("Conectado al servidor");

                ThreadStart ts = delegate { AtenderServidor(); };
                atender = new Thread(ts);
                atender.Start();
            }
            catch (SocketException ex)
            {
                MessageBox.Show("No se pudo conectar con el servidor:\n" + ex.Message);
            }

        }

        private void Registrarse_Click(object sender, EventArgs e)
        {
            // Se toman los datos de los cuadros de texto para usuario y contraseña
            // Se toman los datos de los cuadros de texto para usuario y contraseña
            string usuari = textUsuario.Text.Trim();
            string contrasenya = textPassword.Text.Trim();

            if (usuari == "" || contrasenya == "")
            {
                MessageBox.Show("Introduce usuario y contraseña para registrarte.");
                return;
            }

            else
            {
                string mensaje = $"3/{usuari}/{contrasenya}";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            // Se arma el mensaje de registro (código 3)
        }

        private string usuarioLogueado = ""; // Declarar la variable a nivel de clase
        private void Login_Click(object sender, EventArgs e)
        {
            // Dado que el servidor no implementa una operación de login,
            // en este ejemplo simplemente se comprueba que se hayan ingresado datos.
            string usuari = textUsuario.Text.Trim();
            string contrasenya = textPassword.Text.Trim();

            if (usuari == "" || contrasenya == "")
            {
                MessageBox.Show("Introduce usuario y contraseña para iniciar sesión.");
                return;
            }

            else
            {
                string mensaje = $"2/{usuari}/{contrasenya}";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                usuarioLogueado = usuari;
            }
        }

        // Botón Consulta de puntos totales (Código 4)
        private void ConsultaTotal_Click(object sender, EventArgs e)
        {
            if (usuarioLogueado == "")
            {
                MessageBox.Show("Debes iniciar sesión primero.");
                return;
            }

            // Se arma el mensaje para consultar los puntos totales (código 4)
            string mensaje = $"4/{usuarioLogueado}";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }
        
        // Botón Consulta de puntos por partida (Código 5)
        private void ConsultaPartida_Click(object sender, EventArgs e)
        {
            // Se toma el id de partida desde el cuadro de texto correspondiente
            string idPartida = textIdPartida.Text.Trim();
            if (idPartida == "")
            {
                MessageBox.Show("Introduce el ID de la partida para la consulta.");
                return;
            }

            string mensaje = $"5/{idPartida}";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        // Botón Consulta del récord (Código 6)
        private void ConsultaRecord_Click(object sender, EventArgs e)
        {
            // Se toma el id de partida desde el cuadro de texto correspondiente
            string idPartida = textIdPartida.Text.Trim();
            if (idPartida == "")
            {
                MessageBox.Show("Introduce el ID de la partida para la consulta.");
                return;
            }
            // Para el récord no se necesitan parámetros adicionales
            string mensaje = $"6/{idPartida}";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }
        
        // Botón Desconectar
        private void Desconectar_Click(object sender, EventArgs e)
        {
            try
            {
                // Se envía el mensaje de desconexión (código 0)
                string mensaje = "0/";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                atender.Abort();

                server.Shutdown(SocketShutdown.Both);
                server.Close();
                this.BackColor = Color.Gray;
                Conectados.Rows.Clear();
                MessageBox.Show("Desconectado del servidor");
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Error al desconectar:\n" + ex.Message);
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            Conectados.Columns.Add("Usuari", "Usuaris connectats");
            Conectados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        }
    }
}



