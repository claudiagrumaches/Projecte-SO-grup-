﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace cliente_V1
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;
        Thread chat1;
        Thread chat2;
        Thread chat3;
        string[] jugadores = { "x", "x", "x", "x" };
        int num = 1;
        int contadorPartidas = 0;

        public Form1()
        {
            InitializeComponent();
            //CheckForIllegalCrossThreadCalls = false; Lo dejamos por si acaso como comentario, pero ya no debería hacer falta con los delegates.
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private Form3 form3;

        private void AtenderServidor()
        {
            while (true)
            {
                byte[] msg2 = new byte[80];
                server.Receive(msg2);

                string mensajeCompleto = Encoding.ASCII.GetString(msg2).Split('\0')[0]; // limpiar basura
                string[] trozos = mensajeCompleto.Split('/');

                int codigo = Convert.ToInt32(trozos[0]);

                switch (codigo)
                {
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        MessageBox.Show(trozos[1]);
                        break;

                    case 7:
                        // Obtener todos los nombres a partir del segundo trozo
                        string[] conectados = trozos.Skip(1).ToArray();

                        Console.WriteLine("Mensaje recibido: [7/" + string.Join("/", conectados) + "]");

                        Conectados.Invoke((MethodInvoker)delegate
                        {
                            if (Conectados.Columns.Count == 0)
                                Conectados.Columns.Add("Usuario", "Usuario Conectado");

                            List<string> usuariosActuales = new List<string>();
                            foreach (DataGridViewRow fila in Conectados.Rows)
                            {
                                if (fila.Cells[0].Value != null)
                                    usuariosActuales.Add(fila.Cells[0].Value.ToString().Trim());
                            }

                            // Eliminar usuarios que ya no están conectados
                            foreach (string usuario in usuariosActuales)
                            {
                                if (!conectados.Contains(usuario))
                                {
                                    foreach (DataGridViewRow fila in Conectados.Rows)
                                    {
                                        if (fila.Cells[0].Value != null && fila.Cells[0].Value.ToString().Trim() == usuario)
                                        {
                                            Conectados.Rows.Remove(fila);
                                            break;
                                        }
                                    }
                                }
                            }

                            // Añadir nuevos usuarios conectados
                            foreach (string usuario in conectados)
                            {
                                string limpio = usuario.Trim();
                                if (!usuariosActuales.Contains(limpio) && !string.IsNullOrWhiteSpace(limpio))
                                {
                                    Conectados.Rows.Add(limpio);
                                }
                            }
                        });
                        break;
                    case 8:
                        anfitrión = trozos[1];
                        invitado = usuarioLogueado;
                        MessageBox.Show("Has recibido una invitación de " + anfitrión + "!");
                        InvitacionLabel.Invoke((MethodInvoker)delegate
                        {
                            InvitacionLabel.Visible = true;
                        });

                        Aceptar.Invoke((MethodInvoker)delegate
                        {
                            Aceptar.Visible = true;
                            Aceptar.Enabled = true;
                        });

                        Rechazar.Invoke((MethodInvoker)delegate
                        {
                            Rechazar.Visible = true;
                            Rechazar.Enabled = true;
                        });
                        break;
                    case 9:
                        if (num <= 3)
                        {
                            if (trozos[2] == "ACEPTAR")
                            {
                                jugadores[0] = textUsuario.Text.Trim();
                                MessageBox.Show(trozos[1] + " ha aceptado tu invitación.");
                                jugadores[num] = trozos[1];
                                num++;
                            }

                            else if (trozos[2] == "RECHAZAR")
                                MessageBox.Show(trozos[1] + " ha rechazado tu invitación :(");
                            else
                                MessageBox.Show("Ha habido un error con la invitación." + trozos[0] + trozos[1] + trozos[2]);
                        }
                        else
                            MessageBox.Show("Ya se ha alcanzado el máximo número de jugadores, no puedes invitar a otros.");
                        break;

                    case 10:
                        jugador_1.Invoke((MethodInvoker)delegate
                        {
                            jugador_1.Text = trozos[1];
                        });

                        jugador_2.Invoke((MethodInvoker)delegate
                        {
                            jugador_2.Text = trozos[2];
                        });

                        jugador_3.Invoke((MethodInvoker)delegate
                        {
                            jugador_3.Text = trozos[3];
                        });

                        jugador_4.Invoke((MethodInvoker)delegate
                        {
                            jugador_4.Text = trozos[4];
                        });

                        int id = Convert.ToInt32(trozos[5]);

                        idLabel.Invoke((MethodInvoker)delegate
                        {
                            idLabel.Text = trozos[5];
                        });

                        MessageBox.Show("¡Todos los jugadores preparados! Empieza el juego.");
                        if (contadorPartidas == 0)
                        {
                            ThreadStart ts = delegate { ThreadChat(); };
                            chat1 = new Thread(ts);
                            chat1.Start();
                        }
                        if (contadorPartidas == 1)
                        {
                            ThreadStart ts = delegate { ThreadChat(); };
                            chat2 = new Thread(ts);
                            chat2.Start();

                        }
                        if (contadorPartidas == 2)
                        {
                            ThreadStart ts = delegate { ThreadChat(); };
                            chat3 = new Thread(ts);
                            chat3.Start();

                        }
                        break;

                    case 11:
                        string remitente = trozos[1];
                        string texto = trozos[2];

                        if (form3 != null)
                        {
                            form3.MostrarMensaje(remitente, texto);
                        }
                        break;

                    case 12:
                        if (trozos[1] == "2")
                            MessageBox.Show("Este usuario no existe");
                        if (trozos[1] == "1")
                            MessageBox.Show("Usuario borrado con éxito");
                        if (trozos[1] == "0")
                            MessageBox.Show("Error al eliminar");
                        break;

                }
            }

        }

        // Botón Conectar
        private void Conectar_Click(object sender, EventArgs e)
        {
            try
            {
                // Se utiliza la IP del servidor y el puerto 9000, que es el definido en el servidor
                IPAddress direc = IPAddress.Parse("192.168.56.102"); //REVISAR QUE LA IP SEA LA CORRECTA 192.168.56.102 per maqquina,10.4.119.6 per shiva
                IPEndPoint ipep = new IPEndPoint(direc, 9080); //50035//9080

                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                server.Connect(ipep);
                this.BackColor = Color.Green;
                MessageBox.Show("Conectado al servidor");

                ThreadStart ts = delegate { AtenderServidor(); };
                atender = new Thread(ts);
                atender.Start();
            }
            catch (SocketException ex)
            {
                MessageBox.Show("No se pudo conectar con el servidor:\n" + ex.Message);
            }

        }

        private void Registrarse_Click(object sender, EventArgs e)
        {
            // Se toman los datos de los cuadros de texto para usuario y contraseña
            
            string usuari = textUsuario.Text.Trim();
            string contrasenya = textPassword.Text.Trim();

            if (usuari == "" || contrasenya == "")
            {
                MessageBox.Show("Introduce usuario y contraseña para registrarte.");
                return;
            }

            else
            {
                string mensaje = $"3/{usuari}/{contrasenya}";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            // Se arma el mensaje de registro (código 3)
        }
        //Botón borrar usuario
        private void borrar_Click(object sender, EventArgs e)
        {
            string usuari = textUsuario.Text.Trim();
            string contrasenya = textPassword.Text.Trim();

            if (usuari == "" || contrasenya == "")
            {
                MessageBox.Show("Introduce usuario y contraseña para poder borrarlo.");
                return;
            }

            else
            {
                string mensaje = $"12/{usuari}/{contrasenya}";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

            }
        }

        private string usuarioLogueado = ""; // Declarar la variable a nivel de clase
        private void Login_Click(object sender, EventArgs e)
        {
            // Dado que el servidor no implementa una operación de login,
            // en este ejemplo simplemente se comprueba que se hayan ingresado datos.
            string usuari = textUsuario.Text.Trim();
            string contrasenya = textPassword.Text.Trim();

            if (usuari == "" || contrasenya == "")
            {
                MessageBox.Show("Introduce usuario y contraseña para iniciar sesión.");
                return;
            }

            else
            {
                string mensaje = $"2/{usuari}/{contrasenya}";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                usuarioLogueado = usuari;
            }
        }

        // Botón Consulta de puntos totales (Código 4)
        private void ConsultaTotal_Click(object sender, EventArgs e)
        {
            if (usuarioLogueado == "")
            {
                MessageBox.Show("Debes iniciar sesión primero.");
                return;
            }

            // Se arma el mensaje para consultar los puntos totales (código 4)
            string mensaje = $"4/{usuarioLogueado}";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }
        
        // Botón Consulta de puntos por partida (Código 5)
        private void ConsultaPartida_Click(object sender, EventArgs e)
        {
            // Se toma el id de partida desde el cuadro de texto correspondiente
            string idPartida = textIdPartida.Text.Trim();
            if (idPartida == "")
            {
                MessageBox.Show("Introduce el ID de la partida para la consulta.");
                return;
            }

            string mensaje = $"5/{idPartida}";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        // Botón Consulta del récord (Código 6)
        private void ConsultaRecord_Click(object sender, EventArgs e)
        {
            // Se toma el id de partida desde el cuadro de texto correspondiente
            string idPartida = textIdPartida.Text.Trim();
            if (idPartida == "")
            {
                MessageBox.Show("Introduce el ID de la partida para la consulta.");
                return;
            }
            // Para el récord no se necesitan parámetros adicionales
            string mensaje = $"6/{idPartida}";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }
        
        // Botón Desconectar
        private void Desconectar_Click(object sender, EventArgs e)
        {
            try
            {
                // Se envía el mensaje de desconexión (código 0)
                string mensaje = $"0/{usuarioLogueado}";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                atender.Abort();

                server.Shutdown(SocketShutdown.Both);
                server.Close();
                this.BackColor = Color.Gray;

                Conectados.Invoke((MethodInvoker)delegate
                {
                    Conectados.Rows.Clear();
                });
                form3.Invoke((MethodInvoker)(() => form3.Close()));
                form3 = null;

                MessageBox.Show("Desconectado del servidor");
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Error al desconectar:\n" + ex.Message);
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            Conectados.Invoke((MethodInvoker)delegate
            {
                Conectados.Columns.Add("Usuari", "Usuaris connectats");
                Conectados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            });

            InvitacionLabel.Invoke((MethodInvoker)delegate
            {
                InvitacionLabel.Visible = false;
            });

            Aceptar.Invoke((MethodInvoker)delegate
            {
                Aceptar.Visible = false;
                Aceptar.Enabled = false;
            });

            Rechazar.Invoke((MethodInvoker)delegate
            {
                Rechazar.Visible = false;
                Rechazar.Enabled = false;
            });           
        }

        string anfitrión = "";
        string invitado = "";

        private void Invitar_Click(object sender, EventArgs e)
        {
            // Verificamos que haya una fila seleccionada
            if (Conectados.CurrentRow != null)
            {
                // Obtenemos el valor de la celda de la columna 0
                invitado = Conectados.CurrentRow.Cells[0].Value.ToString();
                if (usuarioLogueado == "")
                {
                    MessageBox.Show("Debes iniciar sesión primero.");
                    return;
                }
                else 
                {
                    anfitrión = usuarioLogueado;
                    if (invitado == anfitrión)
                    {
                        MessageBox.Show("No puedes invitarte a tí mismo");
                    }
                    else 
                    {
                        string mensaje = $"8/{anfitrión}/{invitado}";
                        byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                        MessageBox.Show("Has invitado a: " + invitado);
                    } 
                }                
            }
            else
            {
                MessageBox.Show("Por favor, selecciona una fila primero.");
            }
        }
        private void Aceptar_Click(object sender, EventArgs e)
        {
            InvitacionLabel.Invoke((MethodInvoker)delegate
            {
                InvitacionLabel.Visible = false;
            });

            Aceptar.Invoke((MethodInvoker)delegate
            {
                Aceptar.Visible = false;
                Aceptar.Enabled = false;
            });

            Rechazar.Invoke((MethodInvoker)delegate
            {
                Rechazar.Visible = false;
                Rechazar.Enabled = false;
            });           

            string mensaje = $"9/{anfitrión}/{invitado}/ACEPTAR";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void Rechazar_Click(object sender, EventArgs e)
        {
            InvitacionLabel.Invoke((MethodInvoker)delegate
            {
                InvitacionLabel.Visible = false;
            });

            Aceptar.Invoke((MethodInvoker)delegate
            {
                Aceptar.Visible = false;
                Aceptar.Enabled = false;
            });

            Rechazar.Invoke((MethodInvoker)delegate
            {
                Rechazar.Visible = false;
                Rechazar.Enabled = false;
            });

            string mensaje = $"9/{anfitrión}/{invitado}/RECHAZAR";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void EmpezarPartida_Click(object sender, EventArgs e)
        {
            if (jugadores[0] == "x")
                MessageBox.Show("Debes invitar almenos a 1 jugador para empezar a jugar. Puedes invitar hasta 3 jugadores.");
            else 
            {
                string mensaje = $"10/{jugadores[0]}/{jugadores[1]}/{jugadores[2]}/{jugadores[3]}";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }         
        }
        private void ThreadChat()
        {
            this.Invoke((MethodInvoker)(() =>
            {
                
                form3 = new Form3(usuarioLogueado, server, jugadores);
                form3.Show();    
            }));
        }

        
    }
}



