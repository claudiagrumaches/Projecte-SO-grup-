﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cliente_V1
{
    public partial class Form2 : Form
    { 
        public string UsuarioLogueado { get; set; }
        public Socket server; // asegúrate de asignarlo desde el Form1
        public Form2()
        {
            InitializeComponent();
        }

        public Form2(string usuarioLogueado, Socket server)
        {
            UsuarioLogueado = usuarioLogueado;
            this.server = server;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
       

        public void MostrarMensaje(string remitente, string texto)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() => MostrarMensaje(remitente, texto)));
                return;
            }

            ChatBox.AppendText($"[{remitente}]: {texto}{Environment.NewLine}");
        }

        private void EnviarChat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(InputChat.Text))
            {
                return;
            }

            string mensaje = $"11/{UsuarioLogueado}/{InputChat.Text.Trim()}";
            byte[] datos = Encoding.ASCII.GetBytes(mensaje);
            server.Send(datos);
            InputChat.Clear();
        }

        private void EnviarChat_Click_1(object sender, EventArgs e)
        {

        }

        private void InputChat_TextChanged(object sender, EventArgs e)
        {

        }

        private void ChatBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
