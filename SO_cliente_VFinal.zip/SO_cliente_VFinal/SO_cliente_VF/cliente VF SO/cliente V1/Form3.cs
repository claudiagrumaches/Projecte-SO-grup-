﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cliente_V1
{
    public partial class Form3 : Form
    {
        public string UsuarioLogueado { get; set; }
        public Socket server; // asegúrate de asignarlo desde el Form1
        public string jugador1;
        public string jugador2;
        public string jugador3;
        public string jugador4;
        public Form3()
        {
            InitializeComponent();            
        }

        public Form3(string usuarioLogueado, Socket server, string[] jugadores)
            : this()
        {
            UsuarioLogueado = usuarioLogueado;
            this.server = server;
            this.jugador1 = jugadores[0];
            this.jugador2 = jugadores[1];
            this.jugador3 = jugadores[2];
            this.jugador4 = jugadores[3];
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            Jug1.Text = jugador1;
            Jug2.Text = jugador2;
            Jug3.Text = jugador3;
            Jug4.Text = jugador4;
        }

        public void MostrarMensaje(string remitente, string texto)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() => MostrarMensaje(remitente, texto)));
                return;
            }

            ChatBox.AppendText($"[{remitente}]: {texto}{Environment.NewLine}");
        }
        private void EnviarChat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(InputChat.Text))
            {
                return;
            }

            string mensaje = $"11/{UsuarioLogueado}/{InputChat.Text.Trim()}";
            byte[] datos = Encoding.ASCII.GetBytes(mensaje);
            server.Send(datos);
            InputChat.Clear();
        }
    }
}
