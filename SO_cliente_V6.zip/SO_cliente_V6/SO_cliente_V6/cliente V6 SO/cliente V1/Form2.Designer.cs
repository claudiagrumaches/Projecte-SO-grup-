﻿namespace cliente_V
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EnviarChat = new System.Windows.Forms.Button();
            this.ChatBox = new System.Windows.Forms.TextBox();
            this.InputChat = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // EnviarChat
            // 
            this.EnviarChat.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnviarChat.Location = new System.Drawing.Point(707, 480);
            this.EnviarChat.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EnviarChat.Name = "EnviarChat";
            this.EnviarChat.Size = new System.Drawing.Size(240, 78);
            this.EnviarChat.TabIndex = 54;
            this.EnviarChat.Text = "Enviar";
            this.EnviarChat.UseVisualStyleBackColor = true;
            this.EnviarChat.Click += new System.EventHandler(this.EnviarChat_Click);
            // 
            // ChatBox
            // 
            this.ChatBox.Location = new System.Drawing.Point(627, 34);
            this.ChatBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ChatBox.Multiline = true;
            this.ChatBox.Name = "ChatBox";
            this.ChatBox.Size = new System.Drawing.Size(370, 379);
            this.ChatBox.TabIndex = 53;
            this.ChatBox.TextChanged += new System.EventHandler(this.ChatBox_TextChanged);
            // 
            // InputChat
            // 
            this.InputChat.Location = new System.Drawing.Point(657, 434);
            this.InputChat.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.InputChat.Name = "InputChat";
            this.InputChat.Size = new System.Drawing.Size(318, 26);
            this.InputChat.TabIndex = 52;
            this.InputChat.TextChanged += new System.EventHandler(this.InputChat_TextChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1061, 564);
            this.Controls.Add(this.EnviarChat);
            this.Controls.Add(this.ChatBox);
            this.Controls.Add(this.InputChat);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EnviarChat;
        private System.Windows.Forms.TextBox ChatBox;
        private System.Windows.Forms.TextBox InputChat;
    }
}