﻿namespace cliente_V1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Conectar = new System.Windows.Forms.Button();
            this.Registrarse = new System.Windows.Forms.Button();
            this.Login = new System.Windows.Forms.Button();
            this.ConsultaTotal = new System.Windows.Forms.Button();
            this.ConsultaPartida = new System.Windows.Forms.Button();
            this.textUsuario = new System.Windows.Forms.TextBox();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ConsultaRecord = new System.Windows.Forms.Button();
            this.textIdPartida = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Desconectar = new System.Windows.Forms.Button();
            this.Escalera = new System.Windows.Forms.Button();
            this.Números = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.jugador_2 = new System.Windows.Forms.Label();
            this.jugador_1 = new System.Windows.Forms.Label();
            this.jugador_3 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.ficha1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.Conectados = new System.Windows.Forms.DataGridView();
            this.Invitar = new System.Windows.Forms.Button();
            this.InvitacionLabel = new System.Windows.Forms.Label();
            this.Aceptar = new System.Windows.Forms.Button();
            this.Rechazar = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.jugador_4 = new System.Windows.Forms.Label();
            this.EmpezarPartida = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.idLabel = new System.Windows.Forms.Label();
            this.btnSaludo = new System.Windows.Forms.Button();
            this.btnBuenaSuerte = new System.Windows.Forms.Button();
            this.btnBienJugado = new System.Windows.Forms.Button();
            this.btnJuegaRapido = new System.Windows.Forms.Button();
            this.InputChat = new System.Windows.Forms.TextBox();
            this.EnviarChat = new System.Windows.Forms.Button();
            this.ChatBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel2.SuspendLayout();
            this.ficha1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Conectados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // Conectar
            // 
            this.Conectar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Conectar.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Conectar.Location = new System.Drawing.Point(12, 369);
            this.Conectar.Name = "Conectar";
            this.Conectar.Size = new System.Drawing.Size(216, 100);
            this.Conectar.TabIndex = 0;
            this.Conectar.Text = "Conectar";
            this.Conectar.UseVisualStyleBackColor = false;
            this.Conectar.Click += new System.EventHandler(this.Conectar_Click);
            // 
            // Registrarse
            // 
            this.Registrarse.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registrarse.Location = new System.Drawing.Point(256, 114);
            this.Registrarse.Name = "Registrarse";
            this.Registrarse.Size = new System.Drawing.Size(220, 72);
            this.Registrarse.TabIndex = 1;
            this.Registrarse.Text = "Registrarse";
            this.Registrarse.UseVisualStyleBackColor = true;
            this.Registrarse.Click += new System.EventHandler(this.Registrarse_Click);
            // 
            // Login
            // 
            this.Login.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login.Location = new System.Drawing.Point(256, 34);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(226, 72);
            this.Login.TabIndex = 2;
            this.Login.Text = "Iniciar Sesión";
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // ConsultaTotal
            // 
            this.ConsultaTotal.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConsultaTotal.Location = new System.Drawing.Point(12, 220);
            this.ConsultaTotal.Name = "ConsultaTotal";
            this.ConsultaTotal.Size = new System.Drawing.Size(114, 103);
            this.ConsultaTotal.TabIndex = 3;
            this.ConsultaTotal.Text = "Consultar puntos totales del usuario";
            this.ConsultaTotal.UseVisualStyleBackColor = true;
            this.ConsultaTotal.Click += new System.EventHandler(this.ConsultaTotal_Click);
            // 
            // ConsultaPartida
            // 
            this.ConsultaPartida.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConsultaPartida.Location = new System.Drawing.Point(146, 223);
            this.ConsultaPartida.Name = "ConsultaPartida";
            this.ConsultaPartida.Size = new System.Drawing.Size(114, 95);
            this.ConsultaPartida.TabIndex = 4;
            this.ConsultaPartida.Text = "Consultar puntos de la partida";
            this.ConsultaPartida.UseVisualStyleBackColor = true;
            this.ConsultaPartida.Click += new System.EventHandler(this.ConsultaPartida_Click);
            // 
            // textUsuario
            // 
            this.textUsuario.Location = new System.Drawing.Point(12, 42);
            this.textUsuario.Name = "textUsuario";
            this.textUsuario.Size = new System.Drawing.Size(202, 26);
            this.textUsuario.TabIndex = 5;
            // 
            // textPassword
            // 
            this.textPassword.Location = new System.Drawing.Point(12, 100);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new System.Drawing.Size(202, 26);
            this.textPassword.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 9.2F);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "Usuario:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MV Boli", 9.2F);
            this.label2.Location = new System.Drawing.Point(12, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "Contraseña:";
            // 
            // ConsultaRecord
            // 
            this.ConsultaRecord.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConsultaRecord.Location = new System.Drawing.Point(278, 223);
            this.ConsultaRecord.Name = "ConsultaRecord";
            this.ConsultaRecord.Size = new System.Drawing.Size(114, 105);
            this.ConsultaRecord.TabIndex = 9;
            this.ConsultaRecord.Text = "Consultar record de puntos de la partida";
            this.ConsultaRecord.UseVisualStyleBackColor = true;
            this.ConsultaRecord.Click += new System.EventHandler(this.ConsultaRecord_Click);
            // 
            // textIdPartida
            // 
            this.textIdPartida.Location = new System.Drawing.Point(12, 178);
            this.textIdPartida.Name = "textIdPartida";
            this.textIdPartida.Size = new System.Drawing.Size(202, 26);
            this.textIdPartida.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 23);
            this.label3.TabIndex = 11;
            this.label3.Text = "ID de Partida:";
            // 
            // Desconectar
            // 
            this.Desconectar.BackColor = System.Drawing.Color.Salmon;
            this.Desconectar.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Desconectar.Location = new System.Drawing.Point(249, 369);
            this.Desconectar.Name = "Desconectar";
            this.Desconectar.Size = new System.Drawing.Size(228, 60);
            this.Desconectar.TabIndex = 12;
            this.Desconectar.Text = "Desconectar";
            this.Desconectar.UseVisualStyleBackColor = false;
            this.Desconectar.Click += new System.EventHandler(this.Desconectar_Click);
            // 
            // Escalera
            // 
            this.Escalera.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Escalera.Location = new System.Drawing.Point(1114, 468);
            this.Escalera.Name = "Escalera";
            this.Escalera.Size = new System.Drawing.Size(128, 68);
            this.Escalera.TabIndex = 14;
            this.Escalera.Text = "Escalera";
            this.Escalera.UseVisualStyleBackColor = true;
            // 
            // Números
            // 
            this.Números.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Números.Location = new System.Drawing.Point(1114, 551);
            this.Números.Name = "Números";
            this.Números.Size = new System.Drawing.Size(130, 65);
            this.Números.TabIndex = 15;
            this.Números.Text = "Iguales";
            this.Números.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("MV Boli", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(1114, 386);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(56, 58);
            this.button2.TabIndex = 16;
            this.button2.Text = "↩️​";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button3.Font = new System.Drawing.Font("MV Boli", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(1182, 386);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(64, 57);
            this.button3.TabIndex = 17;
            this.button3.Text = "✅​";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(1154, 625);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(68, 63);
            this.button4.TabIndex = 18;
            this.button4.Text = "+";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // jugador_2
            // 
            this.jugador_2.AutoSize = true;
            this.jugador_2.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jugador_2.Location = new System.Drawing.Point(567, 322);
            this.jugador_2.Name = "jugador_2";
            this.jugador_2.Size = new System.Drawing.Size(108, 23);
            this.jugador_2.TabIndex = 22;
            this.jugador_2.Text = "Jugador 2";
            // 
            // jugador_1
            // 
            this.jugador_1.AutoSize = true;
            this.jugador_1.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jugador_1.Location = new System.Drawing.Point(807, 22);
            this.jugador_1.Name = "jugador_1";
            this.jugador_1.Size = new System.Drawing.Size(103, 23);
            this.jugador_1.TabIndex = 23;
            this.jugador_1.Text = "Jugador 1";
            // 
            // jugador_3
            // 
            this.jugador_3.AutoSize = true;
            this.jugador_3.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jugador_3.Location = new System.Drawing.Point(812, 671);
            this.jugador_3.Name = "jugador_3";
            this.jugador_3.Size = new System.Drawing.Size(108, 23);
            this.jugador_3.TabIndex = 24;
            this.jugador_3.Text = "Jugador 3";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::cliente_V1.Properties.Resources.avatar1;
            this.pictureBox3.Location = new System.Drawing.Point(801, 562);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(112, 106);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::cliente_V1.Properties.Resources.avatar3;
            this.pictureBox2.Location = new System.Drawing.Point(556, 209);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(111, 114);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::cliente_V1.Properties.Resources.avatar2;
            this.pictureBox1.Location = new System.Drawing.Point(798, 49);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(112, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Wheat;
            this.panel3.Controls.Add(this.panel14);
            this.panel3.Controls.Add(this.panel13);
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Location = new System.Drawing.Point(696, 432);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(364, 122);
            this.panel3.TabIndex = 30;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.Control;
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.label20);
            this.panel14.Location = new System.Drawing.Point(264, 46);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(42, 59);
            this.panel14.TabIndex = 37;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(6, 17);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(17, 21);
            this.label20.TabIndex = 0;
            this.label20.Text = "1";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.Control;
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.label19);
            this.panel13.Location = new System.Drawing.Point(216, 46);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(42, 59);
            this.panel13.TabIndex = 37;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(6, 17);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(24, 21);
            this.label19.TabIndex = 0;
            this.label19.Text = "11";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.Control;
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.label18);
            this.panel12.Location = new System.Drawing.Point(168, 46);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(42, 59);
            this.panel12.TabIndex = 37;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(6, 17);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(22, 21);
            this.label18.TabIndex = 0;
            this.label18.Text = "3";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.Control;
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.label17);
            this.panel11.Location = new System.Drawing.Point(120, 46);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(42, 59);
            this.panel11.TabIndex = 37;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(6, 17);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(22, 21);
            this.label17.TabIndex = 0;
            this.label17.Text = "3";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.Control;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.label16);
            this.panel10.Location = new System.Drawing.Point(72, 46);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(42, 59);
            this.panel10.TabIndex = 37;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label16.Location = new System.Drawing.Point(6, 17);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(21, 21);
            this.label16.TabIndex = 0;
            this.label16.Text = "7";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.Control;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label15);
            this.panel9.Location = new System.Drawing.Point(24, 46);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(42, 59);
            this.panel9.TabIndex = 37;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Blue;
            this.label15.Location = new System.Drawing.Point(6, 17);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(22, 21);
            this.label15.TabIndex = 0;
            this.label15.Text = "2";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Control;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label13);
            this.panel7.Location = new System.Drawing.Point(314, 46);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(42, 59);
            this.panel7.TabIndex = 35;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(8, 18);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 21);
            this.label13.TabIndex = 0;
            this.label13.Text = "5";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(726, 414);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(42, 59);
            this.panel2.TabIndex = 31;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(6, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 21);
            this.label9.TabIndex = 0;
            this.label9.Text = "13";
            // 
            // ficha1
            // 
            this.ficha1.BackColor = System.Drawing.SystemColors.Control;
            this.ficha1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ficha1.Controls.Add(this.label7);
            this.ficha1.Location = new System.Drawing.Point(776, 414);
            this.ficha1.Name = "ficha1";
            this.ficha1.Size = new System.Drawing.Size(42, 59);
            this.ficha1.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(6, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 21);
            this.label7.TabIndex = 0;
            this.label7.Text = "10";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(876, 414);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(42, 59);
            this.panel1.TabIndex = 33;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(6, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 21);
            this.label8.TabIndex = 0;
            this.label8.Text = "13";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label10);
            this.panel4.Location = new System.Drawing.Point(826, 414);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(42, 59);
            this.panel4.TabIndex = 28;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(6, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 21);
            this.label10.TabIndex = 0;
            this.label10.Text = "6";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Control;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label11);
            this.panel5.Location = new System.Drawing.Point(978, 414);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(42, 59);
            this.panel5.TabIndex = 34;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(6, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 21);
            this.label11.TabIndex = 0;
            this.label11.Text = "13";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Control;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label12);
            this.panel6.Location = new System.Drawing.Point(928, 414);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(42, 59);
            this.panel6.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label12.Location = new System.Drawing.Point(6, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 21);
            this.label12.TabIndex = 0;
            this.label12.Text = "10";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.panel8.Controls.Add(this.panel29);
            this.panel8.Controls.Add(this.panel28);
            this.panel8.Controls.Add(this.panel27);
            this.panel8.Controls.Add(this.panel26);
            this.panel8.Controls.Add(this.panel25);
            this.panel8.Controls.Add(this.panel24);
            this.panel8.Controls.Add(this.panel21);
            this.panel8.Controls.Add(this.panel23);
            this.panel8.Controls.Add(this.panel22);
            this.panel8.Controls.Add(this.panel18);
            this.panel8.Controls.Add(this.panel16);
            this.panel8.Controls.Add(this.panel15);
            this.panel8.Location = new System.Drawing.Point(696, 166);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(304, 243);
            this.panel8.TabIndex = 36;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.SystemColors.Control;
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.label34);
            this.panel29.Location = new System.Drawing.Point(148, 83);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(32, 56);
            this.panel29.TabIndex = 39;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label34.Location = new System.Drawing.Point(6, 17);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(22, 21);
            this.label34.TabIndex = 0;
            this.label34.Text = "5";
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.SystemColors.Control;
            this.panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel28.Controls.Add(this.label33);
            this.panel28.Location = new System.Drawing.Point(178, 83);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(32, 56);
            this.panel28.TabIndex = 39;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label33.Location = new System.Drawing.Point(6, 17);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(22, 21);
            this.label33.TabIndex = 0;
            this.label33.Text = "6";
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.SystemColors.Control;
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.label32);
            this.panel27.Location = new System.Drawing.Point(204, 83);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(32, 56);
            this.panel27.TabIndex = 39;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label32.Location = new System.Drawing.Point(6, 17);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(21, 21);
            this.label32.TabIndex = 0;
            this.label32.Text = "7";
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.SystemColors.Control;
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.Controls.Add(this.label31);
            this.panel26.Location = new System.Drawing.Point(231, 83);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(32, 56);
            this.panel26.TabIndex = 39;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label31.Location = new System.Drawing.Point(6, 17);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(22, 21);
            this.label31.TabIndex = 0;
            this.label31.Text = "8";
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.SystemColors.Control;
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Controls.Add(this.label30);
            this.panel25.Location = new System.Drawing.Point(262, 83);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(32, 56);
            this.panel25.TabIndex = 39;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label30.Location = new System.Drawing.Point(6, 17);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(22, 21);
            this.label30.TabIndex = 0;
            this.label30.Text = "9";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.SystemColors.Control;
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.Controls.Add(this.label29);
            this.panel24.Location = new System.Drawing.Point(30, 48);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(32, 56);
            this.panel24.TabIndex = 39;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label29.Location = new System.Drawing.Point(6, 17);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(21, 21);
            this.label29.TabIndex = 0;
            this.label29.Text = "7";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.SystemColors.Control;
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.label26);
            this.panel21.Location = new System.Drawing.Point(76, 162);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(32, 56);
            this.panel21.TabIndex = 39;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label26.Location = new System.Drawing.Point(6, 17);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 21);
            this.label26.TabIndex = 0;
            this.label26.Text = "12";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.SystemColors.Control;
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.label28);
            this.panel23.Location = new System.Drawing.Point(105, 162);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(32, 56);
            this.panel23.TabIndex = 39;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Red;
            this.label28.Location = new System.Drawing.Point(6, 17);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 21);
            this.label28.TabIndex = 0;
            this.label28.Text = "12";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.SystemColors.Control;
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.label27);
            this.panel22.Location = new System.Drawing.Point(130, 162);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(32, 56);
            this.panel22.TabIndex = 38;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Blue;
            this.label27.Location = new System.Drawing.Point(6, 17);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(29, 21);
            this.label27.TabIndex = 0;
            this.label27.Text = "12";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.Control;
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Controls.Add(this.label23);
            this.panel18.Location = new System.Drawing.Point(160, 162);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(32, 56);
            this.panel18.TabIndex = 38;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.SystemColors.Control;
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.label24);
            this.panel19.Location = new System.Drawing.Point(-2, -2);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(32, 56);
            this.panel19.TabIndex = 38;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.SystemColors.Control;
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.label25);
            this.panel20.Location = new System.Drawing.Point(-2, -2);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(32, 56);
            this.panel20.TabIndex = 38;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(6, 17);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 21);
            this.label25.TabIndex = 0;
            this.label25.Text = "12";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label24.Location = new System.Drawing.Point(6, 17);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(22, 21);
            this.label24.TabIndex = 0;
            this.label24.Text = "9";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label23.Location = new System.Drawing.Point(6, 17);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(22, 21);
            this.label23.TabIndex = 0;
            this.label23.Text = "9";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.Control;
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.label21);
            this.panel16.Location = new System.Drawing.Point(87, 48);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(32, 56);
            this.panel16.TabIndex = 38;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(6, 17);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(21, 21);
            this.label21.TabIndex = 0;
            this.label21.Text = "7";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.Control;
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.label14);
            this.panel15.Location = new System.Drawing.Point(57, 48);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(32, 56);
            this.panel15.TabIndex = 37;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(6, 17);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(21, 21);
            this.label14.TabIndex = 0;
            this.label14.Text = "7";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.SystemColors.Control;
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.label22);
            this.panel17.Location = new System.Drawing.Point(904, 200);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(32, 56);
            this.panel17.TabIndex = 38;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("MV Boli", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label22.Location = new System.Drawing.Point(6, 17);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(22, 21);
            this.label22.TabIndex = 0;
            this.label22.Text = "9";
            // 
            // Conectados
            // 
            this.Conectados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Conectados.Location = new System.Drawing.Point(63, 562);
            this.Conectados.Name = "Conectados";
            this.Conectados.RowHeadersWidth = 62;
            this.Conectados.RowTemplate.Height = 28;
            this.Conectados.Size = new System.Drawing.Size(310, 311);
            this.Conectados.TabIndex = 39;
            // 
            // Invitar
            // 
            this.Invitar.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invitar.Location = new System.Drawing.Point(422, 562);
            this.Invitar.Name = "Invitar";
            this.Invitar.Size = new System.Drawing.Size(188, 63);
            this.Invitar.TabIndex = 40;
            this.Invitar.Text = "Invitar";
            this.Invitar.UseVisualStyleBackColor = true;
            this.Invitar.Click += new System.EventHandler(this.Invitar_Click);
            // 
            // InvitacionLabel
            // 
            this.InvitacionLabel.AutoSize = true;
            this.InvitacionLabel.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvitacionLabel.Location = new System.Drawing.Point(450, 882);
            this.InvitacionLabel.Name = "InvitacionLabel";
            this.InvitacionLabel.Size = new System.Drawing.Size(373, 31);
            this.InvitacionLabel.TabIndex = 41;
            this.InvitacionLabel.Text = "¿Desea aceptar la invitación?";
            // 
            // Aceptar
            // 
            this.Aceptar.BackColor = System.Drawing.Color.Lime;
            this.Aceptar.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aceptar.Location = new System.Drawing.Point(862, 868);
            this.Aceptar.Name = "Aceptar";
            this.Aceptar.Size = new System.Drawing.Size(141, 63);
            this.Aceptar.TabIndex = 42;
            this.Aceptar.Text = "ACEPTAR";
            this.Aceptar.UseVisualStyleBackColor = false;
            this.Aceptar.Click += new System.EventHandler(this.Aceptar_Click);
            // 
            // Rechazar
            // 
            this.Rechazar.BackColor = System.Drawing.Color.Tomato;
            this.Rechazar.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rechazar.Location = new System.Drawing.Point(1036, 868);
            this.Rechazar.Name = "Rechazar";
            this.Rechazar.Size = new System.Drawing.Size(141, 63);
            this.Rechazar.TabIndex = 43;
            this.Rechazar.Text = "RECHAZAR";
            this.Rechazar.UseVisualStyleBackColor = false;
            this.Rechazar.Click += new System.EventHandler(this.Rechazar_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::cliente_V1.Properties.Resources.avatar3;
            this.pictureBox4.Location = new System.Drawing.Point(1023, 205);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(111, 114);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 44;
            this.pictureBox4.TabStop = false;
            // 
            // jugador_4
            // 
            this.jugador_4.AutoSize = true;
            this.jugador_4.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jugador_4.Location = new System.Drawing.Point(1032, 322);
            this.jugador_4.Name = "jugador_4";
            this.jugador_4.Size = new System.Drawing.Size(108, 23);
            this.jugador_4.TabIndex = 45;
            this.jugador_4.Text = "Jugador 4";
            // 
            // EmpezarPartida
            // 
            this.EmpezarPartida.BackColor = System.Drawing.Color.Yellow;
            this.EmpezarPartida.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpezarPartida.Location = new System.Drawing.Point(422, 698);
            this.EmpezarPartida.Name = "EmpezarPartida";
            this.EmpezarPartida.Size = new System.Drawing.Size(326, 60);
            this.EmpezarPartida.TabIndex = 46;
            this.EmpezarPartida.Text = "¡EMPEZAR PARTIDA!";
            this.EmpezarPartida.UseVisualStyleBackColor = false;
            this.EmpezarPartida.Click += new System.EventHandler(this.EmpezarPartida_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1232, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(192, 31);
            this.label4.TabIndex = 47;
            this.label4.Text = "ID de Partida:";
            // 
            // idLabel
            // 
            this.idLabel.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idLabel.Location = new System.Drawing.Point(1292, 82);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(66, 46);
            this.idLabel.TabIndex = 48;
            this.idLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSaludo
            // 
            this.btnSaludo.Location = new System.Drawing.Point(0, 0);
            this.btnSaludo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSaludo.Name = "btnSaludo";
            this.btnSaludo.Size = new System.Drawing.Size(112, 35);
            this.btnSaludo.TabIndex = 3;
            // 
            // btnBuenaSuerte
            // 
            this.btnBuenaSuerte.Location = new System.Drawing.Point(0, 0);
            this.btnBuenaSuerte.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnBuenaSuerte.Name = "btnBuenaSuerte";
            this.btnBuenaSuerte.Size = new System.Drawing.Size(112, 35);
            this.btnBuenaSuerte.TabIndex = 2;
            // 
            // btnBienJugado
            // 
            this.btnBienJugado.Location = new System.Drawing.Point(0, 0);
            this.btnBienJugado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnBienJugado.Name = "btnBienJugado";
            this.btnBienJugado.Size = new System.Drawing.Size(112, 35);
            this.btnBienJugado.TabIndex = 1;
            // 
            // btnJuegaRapido
            // 
            this.btnJuegaRapido.Location = new System.Drawing.Point(0, 0);
            this.btnJuegaRapido.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnJuegaRapido.Name = "btnJuegaRapido";
            this.btnJuegaRapido.Size = new System.Drawing.Size(112, 35);
            this.btnJuegaRapido.TabIndex = 0;
            // 
            // InputChat
            // 
            this.InputChat.Location = new System.Drawing.Point(1408, 623);
            this.InputChat.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.InputChat.Name = "InputChat";
            this.InputChat.Size = new System.Drawing.Size(318, 26);
            this.InputChat.TabIndex = 49;
            // 
            // EnviarChat
            // 
            this.EnviarChat.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnviarChat.Location = new System.Drawing.Point(1458, 669);
            this.EnviarChat.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EnviarChat.Name = "EnviarChat";
            this.EnviarChat.Size = new System.Drawing.Size(240, 78);
            this.EnviarChat.TabIndex = 51;
            this.EnviarChat.Text = "Enviar";
            this.EnviarChat.UseVisualStyleBackColor = true;
            this.EnviarChat.Click += new System.EventHandler(this.EnviarChat_Click);
            // 
            // ChatBox
            // 
            this.ChatBox.Location = new System.Drawing.Point(1378, 223);
            this.ChatBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ChatBox.Multiline = true;
            this.ChatBox.Name = "ChatBox";
            this.ChatBox.Size = new System.Drawing.Size(370, 379);
            this.ChatBox.TabIndex = 50;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1822, 982);
            this.Controls.Add(this.btnJuegaRapido);
            this.Controls.Add(this.btnBienJugado);
            this.Controls.Add(this.btnBuenaSuerte);
            this.Controls.Add(this.btnSaludo);
            this.Controls.Add(this.EnviarChat);
            this.Controls.Add(this.ChatBox);
            this.Controls.Add(this.InputChat);
            this.Controls.Add(this.idLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.EmpezarPartida);
            this.Controls.Add(this.jugador_4);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.Rechazar);
            this.Controls.Add(this.Aceptar);
            this.Controls.Add(this.InvitacionLabel);
            this.Controls.Add(this.Invitar);
            this.Controls.Add(this.Conectados);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ficha1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.jugador_3);
            this.Controls.Add(this.jugador_1);
            this.Controls.Add(this.jugador_2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Números);
            this.Controls.Add(this.Escalera);
            this.Controls.Add(this.Desconectar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textIdPartida);
            this.Controls.Add(this.ConsultaRecord);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textPassword);
            this.Controls.Add(this.textUsuario);
            this.Controls.Add(this.ConsultaPartida);
            this.Controls.Add(this.ConsultaTotal);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.Registrarse);
            this.Controls.Add(this.Conectar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ficha1.ResumeLayout(false);
            this.ficha1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Conectados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Conectar;
        private System.Windows.Forms.Button Registrarse;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Button ConsultaTotal;
        private System.Windows.Forms.Button ConsultaPartida;
        private System.Windows.Forms.TextBox textUsuario;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ConsultaRecord;
        private System.Windows.Forms.TextBox textIdPartida;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Desconectar;
        private System.Windows.Forms.Button Escalera;
        private System.Windows.Forms.Button Números;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label jugador_2;
        private System.Windows.Forms.Label jugador_1;
        private System.Windows.Forms.Label jugador_3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel ficha1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DataGridView Conectados;
        private System.Windows.Forms.Button Invitar;
        private System.Windows.Forms.Label InvitacionLabel;
        private System.Windows.Forms.Button Aceptar;
        private System.Windows.Forms.Button Rechazar;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label jugador_4;
        private System.Windows.Forms.Button EmpezarPartida;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label idLabel;
        private System.Windows.Forms.Button btnSaludo;
        private System.Windows.Forms.Button btnBuenaSuerte;
        private System.Windows.Forms.Button btnBienJugado;
        private System.Windows.Forms.Button btnJuegaRapido;
        private System.Windows.Forms.TextBox InputChat;
        private System.Windows.Forms.Button EnviarChat;
        private System.Windows.Forms.TextBox ChatBox;
    }
}

