﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using cliente_V;
using cliente_V1;


namespace cliente_V1
{
    public partial class Form3 : Form
    {
        private string usuarioLogueado;
        private Socket server;
        public Form3(string usuarioRecibido, Socket ServerRecibido)
        {
            InitializeComponent();
            usuarioLogueado = usuarioRecibido;
            server = ServerRecibido;
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        private void EnviarChat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(InputChat.Text))
            {
                return;
            }
            string mensaje = $"11/{usuarioLogueado}/{InputChat.Text.Trim()}";
            byte[] datos = Encoding.ASCII.GetBytes(mensaje);
            server.Send(datos);
            InputChat.Clear();
        }
    }
}
